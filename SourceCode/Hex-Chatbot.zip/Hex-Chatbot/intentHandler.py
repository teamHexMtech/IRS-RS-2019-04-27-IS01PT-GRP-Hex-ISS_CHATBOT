# _*_ coding utf-8 _*_
__author__ = 'Mitch'
__date__ = '5/13/2019 '

import util


# *****************************
# Intent Handlers funcs : START
# *****************************
def get_application_requirement_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(programme_name)['admission']


def get_fees_handler(req):
    if req.get("queryResult").get("parameters").get("GraduateProgram") != '':
        programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
        programme_fee = util.get_programme_detail(programme_name)['fee']
        return programme_fee
    else:
        course_name = req.get("queryResult").get("parameters").get("Course")
        course_fee = util.get_course_detail(course_name)['fee']

        course_fee = course_fee.split('\n')
        fee = []
        fee_dict = {}
        for item in course_fee:
            if '$' in item:
                fee.append(item)
        fee_dict = {'International Participants': fee[0], 'Singaporeans and PR': fee[1]}
        return str(fee_dict)


def get_program_time_table_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    time_table_link = util.get_programme_detail(programme_name)['timetable']
    return "please see the time table detail at {0}.".format(time_table_link)


def get_course_time_table_handler(req):
    course_name = req.get("queryResult").get("parameters").get("Course")
    time_table_link = util.get_course_detail(course_name)['timetable']
    return "please see the time table detail at {0}.".format(time_table_link)


def get_programe_deadline_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return "The application close at {0}.".format(
        util.get_programme_detail(programme_name)['overview']['Application Deadline'])


def get_programe_duration_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return "The application close at {0}.".format(
        util.get_programme_detail(programme_name)['overview']['Duration'])


def get_description_handler(req):
    if req.get("queryResult").get("parameters").get("GraduateProgram") != '':
        return util.get_programme_detail(req.get("queryResult").get("parameters").get("GraduateProgram"))['description']
    else:
        return util.get_course_detail(req.get("queryResult").get("parameters").get("Course"))['description']


def how_to_register_handler(req):
    if req.get("queryResult").get("parameters").get("GraduateProgram") != '':
        return "Please apply the program {0} at {1}".format(
            req.get("queryResult").get("parameters").get("GraduateProgram"),
            "https://inetapps.nus.edu.sg/GDA2/Home.aspx")
    else:
        return "Please register the course {0} at {1}".format(
            req.get("queryResult").get("parameters").get("Course"),
            'https://tms-iss.nus.edu.sg/register/')


def get_application_process_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(req.get("queryResult").get("parameters").get("GraduateProgram"))['apply']


def get_benefit_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(programme_name)['benefit']


def get_career_companies_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(programme_name)['company']


def get_career_prospect_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(programme_name)['prospects']


def get_learning_outcome_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return util.get_programme_detail(programme_name)['outcomes']


def get_link_handler(req):
    if req.get("queryResult").get("parameters").get("GraduateProgram") != '':
        programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
        ans = util.get_all_programme()
        for item in ans:
            if item['name'] == programme_name:
                return 'please see the program information at {0}.'.format(item['link'])
    else:
        course_name = req.get("queryResult").get("parameters").get("Course")
        course_name = course_name.strip('"')
        ans = util.get_course()
        ans = ans[course_name]
        return 'please see the course information at {0}.'.format(ans)


def get_module_handler(req):
    programme_name = req.get("queryResult").get("parameters").get("GraduateProgram")
    return 'We have following module in included in this program:\n{0}'.format(
        str(util.get_programme_detail(programme_name)['module']))
