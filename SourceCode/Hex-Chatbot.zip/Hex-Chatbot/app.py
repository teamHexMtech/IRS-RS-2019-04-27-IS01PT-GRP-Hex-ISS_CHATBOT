# _*_ coding utf-8 _*_

__author__ = 'Mitch'
__date__ = '5/13/2019 '

from flask import Flask, request, make_response, jsonify
import intentHandler

app = Flask(__name__)


# *****************************
# WEBHOOK MAIN ENDPOINT : START
# *****************************

@app.route('/', methods=['POST'])
def web_hook():
    req = request.get_json(silent=True, force=True)
    intent_name = req["queryResult"]["intent"]["displayName"]

    if intent_name == "GetFees":
        response_text = intentHandler.get_fees_handler(req)
    elif intent_name == "GetApplicationProcess":
        response_text = intentHandler.get_application_process_handler(req)
    elif intent_name == "GetApplicationRequirement":
        response_text = intentHandler.get_application_requirement_handler(req)
    elif intent_name == "GetBenefit":
        response_text = intentHandler.get_benefit_handler(req)
    elif intent_name == "GetCareerCompanies":
        response_text = intentHandler.get_career_companies_handler(req)
    elif intent_name == "GetCareerProspect":
        response_text = intentHandler.get_career_prospect_handler(req)
    elif intent_name == "GetCourseTimetable":
        response_text = intentHandler.get_course_time_table_handler(req)
    elif intent_name == "GetProgramTimetable":
        response_text = intentHandler.get_program_time_table_handler(req)
    elif intent_name == "GetDeadline":
        response_text = intentHandler.get_programe_deadline_handler(req)
    elif intent_name == "GetDescription":
        response_text = intentHandler.get_description_handler(req)
    elif intent_name == "GetDuration":
        response_text = intentHandler.get_programe_duration_handler(req)
    elif intent_name == "GetLearningOutcome":
        response_text = intentHandler.get_learning_outcome_handler(req)
    elif intent_name == "GetLink":
        response_text = intentHandler.get_link_handler(req)
    elif intent_name == "GetDescription":
        response_text = intentHandler.get_description_handler(req)
    elif intent_name == "HowToRegister":
        response_text = intentHandler.how_to_register_handler(req)
    elif intent_name == "GetModule":
        response_text = intentHandler.get_module_handler(req)
    else:
        response_text = "No intent matched"
    # Branching ends here

    # Finally sending this response to Dialogflow.
    return make_response(jsonify({'fulfillmentText': str(response_text)}))


# ***************************
# WEBHOOK MAIN ENDPOINT : END
# ***************************

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
