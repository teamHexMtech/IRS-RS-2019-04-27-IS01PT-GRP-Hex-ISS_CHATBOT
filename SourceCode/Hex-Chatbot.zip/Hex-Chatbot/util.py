# _*_ coding utf-8 _*_
__author__ = 'Mitch'
__date__ = '5/13/2019 '

from bs4 import BeautifulSoup, NavigableString
import requests

baseUrl = 'https://www.iss.nus.edu.sg'


# *****************************
# Utility funcs : START
# *****************************

# the function to get all the programmes name and url
def get_all_programme():
    # get the graduate programmes
    iss_page = requests.get(baseUrl + '/graduate-programmes')
    iss_page_html = iss_page.text
    soup = BeautifulSoup(iss_page_html, 'html.parser')
    programmes = soup.find_all('div', {'class': 'col-md-4 animation-element fadeInUp'})

    programme_list = []
    for programme in programmes:
        programme_dict = {'name': programme.contents[1].h3.text.strip(),
                          'link': baseUrl + programme.contents[1].a.get('href'),
                          'type': 'Graduate Programme'}
        programme_list.append(programme_dict)

    # get the stackable programmes
    iss_programme_page = requests.get(baseUrl + '/stackable-certificate-programmes')
    iss_programme_page_html = iss_programme_page.text
    soup = BeautifulSoup(iss_programme_page_html, 'html.parser')
    programmes = soup.find_all('div', {'class': 'panel-body'})

    for programme in programmes:
        if programme.a is not None:
            programme_dict = {'name': programme.a.text, 'link': baseUrl + programme.a.get('href'),
                              'type': 'Stackable Programme'}
            programme_list.append(programme_dict)

    return programme_list


# the function to get all the programmes name
def get_all_programme_name():
    programme_name_list = []
    for item in get_all_programme():
        programme_name_list.append(item['name'])

    return programme_name_list


# the function to get all the course
def get_course():
    course_dict = {}

    for discipline in get_disciplines():
        iss_page = requests.get(discipline['link'])
        iss_page_html = iss_page.text
        soup = BeautifulSoup(iss_page_html, 'html.parser')
        course_soup = soup.find_all('a', {'class': 'course-top--linky'})
        for item in course_soup:
            course_dict[item['title']] = baseUrl + item['href']

    return course_dict


# the function to get the course detail
def get_course_detail(course_name):
    request_url = get_course()[course_name.strip('"')]
    iss_page = requests.get(request_url)
    iss_page_html = iss_page.text
    soup = BeautifulSoup(iss_page_html, 'html.parser')

    # Get the Overview of the course
    course_soup = soup.find('div', {'id': 'overview'}).find('table').find_all('tr')
    course_detail = {}
    course_overview = {}
    for item in course_soup:
        course_overview[item.th.text] = item.td.text.strip()
    course_detail['overview'] = course_overview
    # Get the Overview of the course over here

    # Get the description of the course
    course_soup = soup.find('div', {'id': 'overview'}).find_all('p')
    description = ""
    for item in course_soup:
        description += item.text
    course_detail['description'] = description
    # Get the description of the course over here

    # Get the Key Takeaways of the course
    course_soup = soup.find('div', {'id': 'tab1'}).find_all('li')
    key = ""
    for item in course_soup:
        key += item.get_text().strip() + '\n'
    course_detail['key_takeaways'] = key
    # Get the Key Takeaways of the course over here

    # Get the Who Should Attend the course
    course_detail['who_should_attend'] = soup.find('div', {'id': 'tab2'}).get_text()

    # Get the What Will Be Covered in the course
    course_detail['cover'] = soup.find('div', {'id': 'tab3'}).get_text()

    # Get the Fees and Funding in the course
    course_soup = soup.find('div', {'id': 'tab4'}).select_one("table tr:last-child")
    course_detail['fee'] = course_soup.get_text().strip()
    # Get the Fees and Funding in the course over here

    # Get the Certification of the course
    course_detail['certification'] = soup.find('div', {'id': 'tab5'}).get_text()

    # Get the Preparing for Your Course of the course
    course_detail['preparing'] = soup.find('div', {'id': 'tab6'}).get_text()

    # Get the timetable of the course
    course_detail['timetable'] = request_url

    return course_detail


# the function to get all the programmes detail
def get_programme_detail(programme_name):
    programme_url = ""
    for item in get_all_programme():
        if item['name'] == programme_name:
            programme_url = item['link']
            break
    iss_page = requests.get(programme_url)
    iss_page_html = iss_page.text
    soup = BeautifulSoup(iss_page_html, "html.parser")

    # Get the Overview of the programme
    programme_detail = {}
    programme_overview = {}
    programme_soup = soup.find('div', {'id': 'tabsParent_1'}).find('table').find_all('tr')
    for item in programme_soup:
        programme_overview[item.th.text] = item.td.text.strip()
    programme_detail['overview'] = programme_overview
    # Get the Overview of the programme over here

    # Get the description of the programme
    programme_soup = soup.find('div', {'id': 'tabsParent_1'}).find('div', {'id': 'tab1-container'}).find_all('div', {
        'class': 'col-md-6'})
    description = ''
    for item in programme_soup[0].contents:
        if item.string != '\n':
            description += item.text
    programme_detail['description'] = description
    # Get the description of the programme over here

    # Get the learning outcome of the programme
    p = programme_soup[1].contents
    if 'outcomes' in p[1].text:
        programme_detail['outcomes'] = p[3].text
    else:
        programme_detail['outcomes'] = p[-2].text
    # Get the learning outcome of the programme over here

    # Get the module of the programme
    programme_soup = soup.find('div', {'id': 'tabsParent_2'}).find_all('h4')
    module = []
    for item in programme_soup:
        module.append(item.text)
    programme_detail['module'] = module
    # Get the module of the programme over here

    # Get the Project of the programme
    programme_detail['project'] = soup.find('div', {'id': 'tabsParent_3'}).get_text()

    # Get the Fees & Funding of the programme
    programme_detail['fee'] = soup.find('div', {'id': 'tabsParent_5'}).get_text()

    # Get the Admission & Application of the programme
    p = soup.find('div', {'id': 'tabsParent_6'})
    admission = ''
    for item in p.contents[3].contents:
        if item.string != '\n':
            if "How to Apply" in item.text:
                break
            else:
                admission += item.text
    programme_detail['admission'] = admission
    programme_detail['applicant'] = soup.find('div', {'id': 'tabsParent_6'}).find('ul').get_text()
    # Get how to apply of the programme
    programme_detail['apply'] = soup.find('div', {'id': 'tabsParent_6'}).find('div', {
        'class': 'accordion_block-inner'}).get_text()
    # Get the Admission & Application of the programme over here

    # Get the Career Pathways of the programme
    programme_soup = soup.find('div', {'id': 'tabsParent_7'}).find_all('p')
    pathways = ""
    for item in programme_soup:
        pathways += item.text
    programme_detail['pathways'] = pathways
    # Get the Benefit of the programme
    benefit = ''
    programme_soup = soup.find('div', {'id': 'tab7-container'})
    for item in programme_soup:
        if item.string is None or item.string == 'Career Prospects':
            break
        else:
            benefit += item.string
    programme_detail['benefit'] = benefit
    # Get the Benefit of the programme over here
    # Get the Career Prospects of the programme
    prospects = ''
    programme_soup = soup.find('div', {'id': 'tab7-container'}).find_all('ul')
    for item in programme_soup[0]:
        prospects += item.string
    programme_detail['prospects'] = prospects
    # Get the Career Prospects of the programme over here
    # Get the Career Company of the programme
    company = ''
    if len(programme_soup) >= 2:
        for item in programme_soup[1]:
            company += item.string
        programme_detail['company'] = company
    else:
        programme_detail['company'] = 'this info is not available'
    # Get the Career Company of the programme over here
    # Get the Career Pathways of the programme over here

    # Get the timetable of the programme
    programme_detail['timetable'] = programme_url

    return programme_detail


# get the disciplines list
def get_disciplines():
    disciplines_url = "/executive-education"
    iss_page = requests.get(baseUrl + disciplines_url)
    iss_page_html = iss_page.text
    soup = BeautifulSoup(iss_page_html, "html.parser")
    disciplines_list = []

    discipline_soup = soup.find_all('div', {'class': 'block-accordion-courses--content'})
    for item in discipline_soup:
        disciplines_list.append({'title': item.a['title'], 'link': baseUrl + item.a['href']})

    return disciplines_list
